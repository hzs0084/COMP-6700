Download the fuzzers using:
```bash
mkdir fuzzers && cd fuzzers
gh run download -R paser-group/HPC-Compiler-Fuzzers -n Fuzzers
```
